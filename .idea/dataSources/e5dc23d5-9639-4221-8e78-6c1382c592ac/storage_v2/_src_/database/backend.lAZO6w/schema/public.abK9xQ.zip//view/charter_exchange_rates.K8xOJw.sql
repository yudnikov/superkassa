CREATE VIEW charter_exchange_rates AS
  SELECT row_number() OVER (ORDER BY er.created_at, er.currency_from, er.currency_to) AS id,
    er.currency_from AS from_currency,
    er.currency_to AS to_currency,
        CASE
            WHEN (er.currency_from = 'EUR'::bpchar) THEN (er.value * 1.03)
            ELSE (er.value * 1.02)
        END AS rate,
    er.created_at AS last_updated
   FROM exchange_rates er,
    ( SELECT er_gr.currency_from,
            er_gr.currency_to,
            max(er_gr.valid_from) AS valid_from,
            max(er_gr.created_at) AS created_at
           FROM ( SELECT er_s.currency_from,
                    er_s.currency_to,
                    er_s.valid_from,
                    max(er_s.created_at) AS created_at
                   FROM exchange_rates er_s
                  WHERE (er_s.valid_from <= date(now()))
                  GROUP BY er_s.currency_from, er_s.currency_to, er_s.valid_from) er_gr
          GROUP BY er_gr.currency_from, er_gr.currency_to) er_gr2
  WHERE ((er.currency_from = er_gr2.currency_from) AND (er.currency_to = er_gr2.currency_to) AND (er.valid_from = er_gr2.valid_from) AND (er.created_at = er_gr2.created_at));

