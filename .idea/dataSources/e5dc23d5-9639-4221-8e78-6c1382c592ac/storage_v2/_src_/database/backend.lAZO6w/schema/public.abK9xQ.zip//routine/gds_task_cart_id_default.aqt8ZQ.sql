CREATE FUNCTION gds_task_cart_id_default()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
	IF NEW.cart_id IS NULL THEN
		BEGIN
			NEW.cart_id = NEW.input::JSON->>'cart_id';
		EXCEPTION WHEN invalid_text_representation THEN
		END;
	END IF;
	RETURN NEW;
END;
$$;

