CREATE FUNCTION transfer_task_name_default()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
	IF NEW.task_name IS NULL THEN
		BEGIN
			NEW.task_name = NEW.input::JSON->>'task';
		EXCEPTION WHEN invalid_text_representation THEN
		END;
	END IF;
	RETURN NEW;
END;
$$;

